VINDECORD LIVE ORDERS - IMPORTANT

What was added:
- Admin > Payment Settings screen with Provider, Merchant/Account ID, Public/Client Key and Webhook URL.
- Admin dashboard can read live orders from GET /api/orders and refresh every 15 seconds.
- Backend skeleton (server.js) with persistent JSON order storage.
- POST /api/orders for creating an order.
- POST /api/webhook for payment-provider webhook updates, protected by X-Webhook-Secret.
- Environment variable template in .env.example.

Run locally:
1. Install Node.js 18+.
2. Copy .env.example to .env and set ADMIN_PASSWORD and WEBHOOK_SECRET.
3. Start with: node server.js
4. Open http://localhost:3000

Production:
- Deploy this folder on a Node-capable host.
- Use a real database instead of JSON for high-volume production.
- Replace the generic webhook secret with the payment provider's official signature verification.
- Choose your actual payment provider (for example Stripe, PayPal, etc.) and implement its checkout/session creation + webhook verification. This package intentionally does NOT pretend that a payment succeeded.
- Keep secret API keys only in server environment variables.
- Change the admin credentials before production.

Order notification:
The dashboard polls /api/orders every 15 seconds. For email/WhatsApp/Telegram notifications, add a notification provider in server.js after a verified paid webhook.


PAYPAL + CREDIT/DEBIT CARD
===========================
This build includes PayPal checkout and PayPal-hosted credit/debit card fields when your PayPal account is eligible for Advanced Credit and Debit Card Payments. The browser never receives the PayPal secret.

1. Copy .env.example to .env.
2. Create a PayPal REST app and put its Client ID and Client Secret in .env.
3. Keep PAYPAL_MODE=sandbox for testing.
4. For live payments, use your live REST app credentials and set PAYPAL_MODE=live.
5. If PayPal has enabled Advanced Card Payments for your account, set PAYPAL_MERCHANT_ID too; otherwise the PayPal button can still work without the custom card fields.
6. Run: npm start
7. Open the site through http://localhost:3000 (do not open index.html directly).

The server calculates the amount from the selected package/currency instead of trusting the browser amount. Successful PayPal captures are written to data/orders.json and appear in the Admin Dashboard.
