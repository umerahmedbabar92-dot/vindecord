const fs = require('fs');
const path = require('path');
let pool = null;
try {
  if (process.env.DATABASE_URL) {
    const { Pool } = require('pg');
    pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false }, max: 5 });
  }
} catch (e) {
  console.warn('Postgres driver unavailable; using local file storage.', e.message);
}

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const ORDERS_FILE = path.join(DATA_DIR, 'orders.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, '[]');

async function initDb() {
  if (!pool) return;
  await pool.query(`CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    paypal_order_id TEXT,
    paypal_capture_id TEXT,
    customer TEXT NOT NULL DEFAULT '',
    email TEXT NOT NULL DEFAULT '',
    vin TEXT NOT NULL,
    country TEXT NOT NULL DEFAULT 'NZ',
    pkg TEXT NOT NULL,
    payment TEXT NOT NULL DEFAULT 'Pending',
    report TEXT NOT NULL DEFAULT 'Pending',
    amount NUMERIC(12,2) NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'NZD',
    report_token TEXT,
    report_data JSONB,
    date TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    paid_at TIMESTAMPTZ
  )`);
  await pool.query(`CREATE INDEX IF NOT EXISTS orders_report_token_idx ON orders(report_token)`);
}

function readFileOrders(){ try { return JSON.parse(fs.readFileSync(ORDERS_FILE,'utf8')); } catch { return []; } }
function writeFileOrders(x){ fs.writeFileSync(ORDERS_FILE, JSON.stringify(x,null,2)); }

async function getOrders(){
  if (!pool) return readFileOrders();
  const { rows } = await pool.query(`SELECT id, paypal_order_id AS "paypalOrderId", paypal_capture_id AS "paypalCaptureId", customer, email, vin, country, pkg, payment, report, amount::float AS amount, currency, report_token AS "reportToken", report_data AS "reportData", date, created_at AS "createdAt", paid_at AS "paidAt" FROM orders ORDER BY created_at DESC`);
  return rows;
}

async function getOrder(id){
  if (!pool) return readFileOrders().find(o=>o.id===id) || null;
  const { rows } = await pool.query(`SELECT id, paypal_order_id AS "paypalOrderId", paypal_capture_id AS "paypalCaptureId", customer, email, vin, country, pkg, payment, report, amount::float AS amount, currency, report_token AS "reportToken", report_data AS "reportData", date, created_at AS "createdAt", paid_at AS "paidAt" FROM orders WHERE id=$1`, [id]);
  return rows[0] || null;
}

async function insertOrder(o){
  if (!pool) { const x=readFileOrders(); x.unshift(o); writeFileOrders(x); return o; }
  await pool.query(`INSERT INTO orders (id,paypal_order_id,customer,email,vin,country,pkg,payment,report,amount,currency,report_token,report_data,date,created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)`, [o.id,o.paypalOrderId||null,o.customer||'',o.email||'',o.vin,o.country||'NZ',o.pkg,o.payment||'Pending',o.report||'Pending',o.amount||0,o.currency||'NZD',o.reportToken||null,o.reportData?JSON.stringify(o.reportData):null,o.date||new Date().toISOString().slice(0,10),o.createdAt||new Date().toISOString()]);
  return o;
}

async function updateOrder(id, patch){
  if (!pool) { const x=readFileOrders(); const i=x.findIndex(o=>o.id===id); if(i<0) return null; x[i]={...x[i],...patch}; writeFileOrders(x); return x[i]; }
  const allowed = {paypalOrderId:'paypal_order_id',paypalCaptureId:'paypal_capture_id',customer:'customer',email:'email',vin:'vin',country:'country',pkg:'pkg',payment:'payment',report:'report',amount:'amount',currency:'currency',reportToken:'report_token',reportData:'report_data',date:'date',createdAt:'created_at',paidAt:'paid_at'};
  const sets=[]; const vals=[]; let n=1;
  for(const [k,v] of Object.entries(patch)){ if(!allowed[k]) continue; sets.push(`${allowed[k]}=$${n++}`); vals.push(k==='reportData' ? JSON.stringify(v) : v); }
  if(!sets.length) return getOrder(id);
  vals.push(id); const { rows }=await pool.query(`UPDATE orders SET ${sets.join(', ')} WHERE id=$${n} RETURNING id`, vals); if(!rows.length) return null; return getOrder(id);
}

async function findByPayPal(paypalOrderId){
  if (!pool) return readFileOrders().find(o=>o.paypalOrderId===paypalOrderId) || null;
  const { rows }=await pool.query(`SELECT id, paypal_order_id AS "paypalOrderId", paypal_capture_id AS "paypalCaptureId", customer, email, vin, country, pkg, payment, report, amount::float AS amount, currency, report_token AS "reportToken", report_data AS "reportData", date, created_at AS "createdAt", paid_at AS "paidAt" FROM orders WHERE paypal_order_id=$1`, [paypalOrderId]); return rows[0]||null;
}

async function findByReportToken(token){
  if (!pool) return readFileOrders().find(o=>o.reportToken===token) || null;
  const { rows }=await pool.query(`SELECT id, customer, email, vin, country, pkg, payment, report, amount::float AS amount, currency, report_token AS "reportToken", report_data AS "reportData", date, created_at AS "createdAt", paid_at AS "paidAt" FROM orders WHERE report_token=$1`, [token]); return rows[0]||null;
}

module.exports={pool,initDb,getOrders,getOrder,insertOrder,updateOrder,findByPayPal,findByReportToken};
