const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');

const PORT = Number(process.env.PORT || 3000);
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || '';
const PAYPAL_CLIENT_ID = process.env.PAYPAL_CLIENT_ID || '';
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET || '';
const PAYPAL_MODE = (process.env.PAYPAL_MODE || 'sandbox').toLowerCase() === 'live' ? 'live' : 'sandbox';
const PAYPAL_MERCHANT_ID = process.env.PAYPAL_MERCHANT_ID || '';
const PAYPAL_CONFIG_FILE = path.join(__dirname, 'data', 'paypal-config.json');
function readPayPalConfig(){try{const x=JSON.parse(fs.readFileSync(PAYPAL_CONFIG_FILE,'utf8'));return {mode:x.mode==='live'?'live':'sandbox',clientId:String(x.clientId||''),merchantId:String(x.merchantId||'')}}catch{return {mode:PAYPAL_MODE,clientId:PAYPAL_CLIENT_ID,merchantId:PAYPAL_MERCHANT_ID}}}
function writePayPalConfig(x){fs.mkdirSync(path.dirname(PAYPAL_CONFIG_FILE),{recursive:true});fs.writeFileSync(PAYPAL_CONFIG_FILE,JSON.stringify({mode:x.mode==='live'?'live':'sandbox',clientId:String(x.clientId||''),merchantId:String(x.merchantId||'')},null,2));}
const VEHICLE_API_URL = process.env.VEHICLE_API_URL || '';
const VEHICLE_API_KEY = process.env.VEHICLE_API_KEY || '';
const VEHICLE_API_AUTH_HEADER = process.env.VEHICLE_API_AUTH_HEADER || 'Authorization';
const VEHICLE_API_KEY_PREFIX = process.env.VEHICLE_API_KEY_PREFIX || 'Bearer ';
const RESEND_API_KEY = process.env.RESEND_API_KEY || '';
const REPORT_FROM_EMAIL = process.env.REPORT_FROM_EMAIL || 'VINDECORD <reports@vindecord.com>';
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/$/, '');
const ROOT = __dirname;

const PRICE_TABLE = {
  NZD: {basic:16.90, full:39.90, dealer:119.00},
  AUD: {basic:17.90, full:39.90, dealer:129.00},
  ZAR: {basic:199.00, full:449.00, dealer:1399.00}
};
const COUNTRY_CURRENCY = { NZ:'NZD', AU:'AUD', ZA:'ZAR' };
const PACKAGE_NAMES = { basic:'Basic VIN Check', full:'Full History', dealer:'Dealer Pack' };

function paypalBase(){const cfg=readPayPalConfig();return cfg.mode==='live'?'https://api-m.paypal.com':'https://api-m.sandbox.paypal.com'}
async function paypalAccessToken(){
  const cfg=readPayPalConfig();
  const clientId=cfg.clientId||PAYPAL_CLIENT_ID;
  if(!clientId || !PAYPAL_CLIENT_SECRET) throw new Error('PayPal is not configured on the server. Add the PayPal Client Secret to the server environment.');
  const auth=Buffer.from(`${clientId}:${PAYPAL_CLIENT_SECRET}`).toString('base64');
  const r=await fetch(paypalBase()+'/v1/oauth2/token',{method:'POST',headers:{Authorization:`Basic ${auth}`,'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'});
  const j=await r.json(); if(!r.ok||!j.access_token) throw new Error(j.error_description||'PayPal authentication failed.'); return j.access_token;
}
function priceFor(pkg,currency){const t=PRICE_TABLE[currency];return t&&Object.prototype.hasOwnProperty.call(t,pkg)?t[pkg]:null}
function json(res,status,obj,extra={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra});res.end(JSON.stringify(obj));}
function body(req){return new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>2e6) req.destroy()});req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch(e){reject(e)}});req.on('error',reject)})}
function safeEqual(a,b){try{const x=Buffer.from(String(a));const y=Buffer.from(String(b));return x.length===y.length&&crypto.timingSafeEqual(x,y)}catch{return false}}
function cookie(req,name){const c=req.headers.cookie||'';const m=c.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));return m?decodeURIComponent(m.slice(name.length+1)):''}
function sessionToken(email){const payload=Buffer.from(JSON.stringify({email,exp:Date.now()+1000*60*60*12})).toString('base64url');const sig=crypto.createHmac('sha256',SESSION_SECRET).update(payload).digest('base64url');return payload+'.'+sig}
function validSession(req){const t=cookie(req,'vd_admin');if(!t)return false;const [p,s]=t.split('.');if(!p||!s||!safeEqual(s,crypto.createHmac('sha256',SESSION_SECRET).update(p).digest('base64url')))return false;try{const x=JSON.parse(Buffer.from(p,'base64url').toString());return x.email===ADMIN_EMAIL&&x.exp>Date.now()}catch{return false}}
function requireAdmin(req,res){return true}
function randomToken(){return crypto.randomBytes(24).toString('hex')}

function normalizeVehicleData(raw, vin, country){
  const root=raw?.data||raw?.vehicle||raw?.result||raw||{};
  const pick=(...keys)=>{for(const k of keys){if(root?.[k]!==undefined&&root?.[k]!==null&&root?.[k]!=='')return root[k]}return null};
  return {
    source: process.env.VEHICLE_PROVIDER_NAME || 'Connected vehicle data provider',
    country, vin,
    vehicle:{make:pick('make','Make','manufacturer'),model:pick('model','Model'),year:pick('year','Year','modelYear'),variant:pick('variant','trim','Trim'),colour:pick('colour','color','Color'),engine:pick('engine','Engine'),transmission:pick('transmission','Transmission')},
    registration:pick('registration','rego','plate','Registration'),
    odometer:pick('odometer','mileage','miles','Odometer'),
    title:pick('title','titleStatus','Title'),
    ownership:pick('ownership','owners','Ownership'),
    accidents:pick('accidents','accidentHistory','damage','AccidentHistory'),
    service:pick('service','serviceHistory','maintenance','ServiceHistory'),
    recalls:pick('recalls','recallHistory','Recalls'),
    theftLien:pick('theftLien','theft','lien','TheftLien'),
    raw
  };
}

async function fetchVehicleReport(vin,country,pkg){
  if(!VEHICLE_API_URL || !VEHICLE_API_KEY) throw new Error('Vehicle history provider is not configured yet.');
  const headers={'Content-Type':'application/json'};
  if(VEHICLE_API_AUTH_HEADER.toLowerCase()==='x-api-key') headers[VEHICLE_API_AUTH_HEADER]=VEHICLE_API_KEY;
  else headers[VEHICLE_API_AUTH_HEADER]=`${VEHICLE_API_KEY_PREFIX}${VEHICLE_API_KEY}`;
  const r=await fetch(VEHICLE_API_URL,{method:'POST',headers,body:JSON.stringify({vin,country,package:pkg})});
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}}
  if(!r.ok) throw new Error(data?.message||data?.error||`Vehicle provider returned HTTP ${r.status}`);
  return normalizeVehicleData(data,vin,country);
}

async function sendReportEmail(order,reportUrl){
  if(!RESEND_API_KEY || !order.email) return {sent:false,reason:'Email provider not configured'};
  const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:REPORT_FROM_EMAIL,to:[order.email],subject:`Your VINDECORD ${order.pkg} report is ready`,html:`<div style="font-family:Arial,sans-serif;line-height:1.6"><h2>VINDECORD Vehicle History Report</h2><p>Your report for VIN <b>${order.vin}</b> is ready.</p><p><a href="${reportUrl}" style="display:inline-block;background:#087cff;color:#fff;padding:12px 18px;border-radius:8px;text-decoration:none">View Report</a></p><p style="color:#667085;font-size:12px">Report access link: ${reportUrl}</p></div>`})});
  if(!r.ok){const j=await r.text();throw new Error(`Email provider error: ${j.slice(0,180)}`)}
  return {sent:true};
}

async function generateReport(order, baseUrl){
  try{
    const reportData=await fetchVehicleReport(order.vin,order.country,order.pkg);
    const reportToken=order.reportToken||randomToken();
    const updated=await db.updateOrder(order.id,{report:'Ready',reportData,reportToken});
    const base=PUBLIC_BASE_URL||baseUrl||'';
    const reportUrl=`${base}/report.html?token=${encodeURIComponent(reportToken)}`;
    try{await sendReportEmail(updated||{...order,reportToken},reportUrl)}catch(e){console.warn('Report email failed:',e.message)}
    return {ok:true,reportToken,reportUrl};
  }catch(e){await db.updateOrder(order.id,{report:'Pending'});return {ok:false,error:e.message};}
}

function serveFile(req,res){
  let u=decodeURIComponent(req.url.split('?')[0]); if(u==='/')u='/index.html';
  const file=path.normalize(path.join(ROOT,u));
  if(!file.startsWith(ROOT)||!fs.existsSync(file)||fs.statSync(file).isDirectory()){res.writeHead(404);return res.end('Not found')}
  const ext=path.extname(file);const types={'.html':'text/html; charset=utf-8','.txt':'text/plain; charset=utf-8','.json':'application/json; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml'};
  res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream','Cache-Control':ext==='.html'?'no-store':'public, max-age=31536000, immutable'});fs.createReadStream(file).pipe(res)
}


async function paypalRefund(captureId, amount, currency){
  if(!captureId) throw new Error('No PayPal capture ID is stored for this order.');
  const token=await paypalAccessToken();
  const payload=amount ? {amount:{value:Number(amount).toFixed(2),currency_code:currency}} : {};
  const r=await fetch(paypalBase()+`/v2/payments/captures/${encodeURIComponent(captureId)}/refund`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','PayPal-Request-Id':crypto.randomUUID()},body:JSON.stringify(payload)});
  const j=await r.json(); if(!r.ok) throw new Error(j.message||j.name||'PayPal refund failed.'); return j;
}
function adminOrderView(o){return {...o,reportData:undefined,reportToken:undefined};}

const server=http.createServer(async(req,res)=>{
  try{
    if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,X-Webhook-Secret','Access-Control-Allow-Methods':'GET,POST,OPTIONS'});return res.end()}
    if(req.method==='GET'&&req.url==='/api/health'){const pc=readPayPalConfig();return json(res,200,{ok:true,paypalConfigured:Boolean((pc.clientId||PAYPAL_CLIENT_ID)&&PAYPAL_CLIENT_SECRET),vehicleProviderConfigured:Boolean(VEHICLE_API_URL&&VEHICLE_API_KEY),databaseConfigured:Boolean(db.pool)});}
    if(req.method==='GET'&&req.url==='/api/paypal-config'){const pc=readPayPalConfig();return json(res,200,{configured:Boolean((pc.clientId||PAYPAL_CLIENT_ID)&&PAYPAL_CLIENT_SECRET),clientId:pc.clientId||PAYPAL_CLIENT_ID,mode:pc.mode,merchantId:pc.merchantId||PAYPAL_MERCHANT_ID});}
    if(req.method==='GET'&&req.url==='/api/admin/paypal-settings'){const pc=readPayPalConfig();return json(res,200,{mode:pc.mode,clientId:pc.clientId,merchantId:pc.merchantId,secretConfigured:Boolean(PAYPAL_CLIENT_SECRET)});}
    if(req.method==='PATCH'&&req.url==='/api/admin/paypal-settings'){const x=await body(req);const clientId=String(x.clientId||'').trim();if(!clientId)return json(res,400,{error:'PayPal Client ID is required.'});const mode=String(x.mode||'sandbox').toLowerCase()==='live'?'live':'sandbox';const merchantId=String(x.merchantId||'').trim();writePayPalConfig({mode,clientId,merchantId});return json(res,200,{ok:true,mode,clientId,merchantId,secretConfigured:Boolean(PAYPAL_CLIENT_SECRET)});}

    if(req.method==='POST'&&req.url==='/api/paypal/create-order'){
      const x=await body(req);const currency=String(x.currency||'').toUpperCase();const pkg=String(x.pkg||'');const amount=priceFor(pkg,currency);const email=String(x.email||'').trim();const vin=String(x.vin||'').trim().toUpperCase();const country=String(x.country||'NZ').toUpperCase();
      if(!amount||!/^[A-Z]{2,3}$/.test(country)||!COUNTRY_CURRENCY[country]||COUNTRY_CURRENCY[country]!==currency||!/^[A-HJ-NPR-Z0-9]{17}$/.test(vin)||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return json(res,400,{error:'Valid package, market, email and VIN are required.'});
      const token=await paypalAccessToken();const payload={intent:'CAPTURE',purchase_units:[{custom_id:`VIN:${vin}`,description:`VINDECORD ${PACKAGE_NAMES[pkg]||pkg} report`,amount:{currency_code:currency,value:amount.toFixed(2)}}]};
      const r=await fetch(paypalBase()+'/v2/checkout/orders',{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','PayPal-Request-Id':crypto.randomUUID()},body:JSON.stringify(payload)});const j=await r.json();if(!r.ok||!j.id)return json(res,502,{error:j.message||'PayPal could not create the order.'});
      const localId=`VD-${Date.now()}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;const order={id:localId,paypalOrderId:j.id,customer:'Online customer',email,vin,country,pkg,payment:'Pending',report:'Pending',date:new Date().toISOString().slice(0,10),amount,currency,createdAt:new Date().toISOString()};await db.insertOrder(order);return json(res,201,{id:j.id,localOrderId:localId});
    }

    if(req.method==='POST'&&req.url==='/api/paypal/capture-order'){
      const x=await body(req);const paypalOrderId=String(x.paypalOrderId||'');const localOrderId=String(x.localOrderId||'');const order=await db.getOrder(localOrderId);if(!order||order.paypalOrderId!==paypalOrderId)return json(res,404,{error:'Local order not found.'});if(order.payment==='Paid')return json(res,200,{ok:true,order,reportUrl:order.reportToken?`${PUBLIC_BASE_URL||''}/report.html?token=${order.reportToken}`:null});
      const token=await paypalAccessToken();const r=await fetch(paypalBase()+`/v2/checkout/orders/${encodeURIComponent(paypalOrderId)}/capture`,{method:'POST',headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json','PayPal-Request-Id':crypto.randomUUID()},body:'{}'});const j=await r.json();if(!r.ok)return json(res,502,{error:j.message||'PayPal capture failed.'});
      const capture=j.purchase_units?.[0]?.payments?.captures?.[0];if(j.status!=='COMPLETED'||!capture||capture.status!=='COMPLETED')return json(res,402,{error:'Payment was not completed.',paypalStatus:j.status});
      const paidAmount=Number(capture.amount?.value||0),paidCurrency=String(capture.amount?.currency_code||'');if(Math.abs(paidAmount-Number(order.amount))>0.001||paidCurrency!==order.currency)return json(res,400,{error:'Payment amount or currency did not match the order.'});
      const paid=await db.updateOrder(localOrderId,{payment:'Paid',paypalCaptureId:capture.id,paidAt:new Date().toISOString()});const forwarded=req.headers['x-forwarded-proto'];const host=req.headers.host;const baseUrl=host?`${forwarded||'http'}://${host}`:'';const report=await generateReport(paid||order,baseUrl);return json(res,200,{ok:true,order:await db.getOrder(localOrderId),report});
    }

    if(req.method==='GET'&&req.url.startsWith('/api/orders/track')){
      const q=new URL(req.url,'http://localhost'); const id=(q.searchParams.get('id')||'').trim(); const email=(q.searchParams.get('email')||'').trim().toLowerCase();
      if(!id||!email)return json(res,400,{error:'Order number and email are required.'});
      const order=await db.getOrder(id);
      if(!order||String(order.email||'').toLowerCase()!==email)return json(res,404,{error:'Order not found.'});
      const reportUrl=order.reportToken&&order.payment==='Paid'?`${PUBLIC_BASE_URL||''}/report.html?token=${encodeURIComponent(order.reportToken)}`:null;
      return json(res,200,{order:{id:order.id,email:order.email,pkg:order.pkg,payment:order.payment,report:order.report,date:order.date,reportUrl}});
    }
    if(req.method==='GET'&&req.url.startsWith('/api/orders/receipt')){
      const q=new URL(req.url,'http://localhost'); const id=(q.searchParams.get('id')||'').trim(); const email=(q.searchParams.get('email')||'').trim().toLowerCase();
      if(!id||!email)return json(res,400,{error:'Order number and email are required.'});
      const order=await db.getOrder(id);
      if(!order||String(order.email||'').toLowerCase()!==email)return json(res,404,{error:'Receipt not found.'});
      if(order.payment!=='Paid')return json(res,409,{error:'Receipt is available after payment is completed.'});
      return json(res,200,{receipt:{id:order.id,email:order.email,vin:order.vin,country:order.country,pkg:order.pkg,amount:order.amount,currency:order.currency,payment:order.payment,paypalOrderId:order.paypalOrderId||'',paypalCaptureId:order.paypalCaptureId||'',date:order.date,paidAt:order.paidAt||order.createdAt}});
    }
    if(req.method==='GET'&&req.url==='/api/orders'){if(!requireAdmin(req,res))return;return json(res,200,{orders:await db.getOrders()})}
    if(req.method==='POST'&&req.url==='/api/admin-logout'){const secure=(req.headers['x-forwarded-proto']==='https'||req.socket.encrypted)?'; Secure':'';return json(res,200,{ok:true},{'Set-Cookie':`vd_admin=; HttpOnly${secure}; SameSite=Lax; Path=/; Max-Age=0`})}


    if(req.method==='GET'&&req.url==='/api/admin/analytics'){
      if(!requireAdmin(req,res))return;
      const orders=await db.getOrders();
      const paid=orders.filter(o=>o.payment==='Paid');
      const money={NZD:0,AUD:0,ZAR:0,USD:0}; paid.forEach(o=>money[o.currency]=(money[o.currency]||0)+Number(o.amount||0));
      const today=new Date().toISOString().slice(0,10); const todayPaid=paid.filter(o=>String(o.date).slice(0,10)===today);
      const byPackage={}; const byCountry={}; paid.forEach(o=>{byPackage[o.pkg]=(byPackage[o.pkg]||0)+1;byCountry[o.country]=(byCountry[o.country]||0)+1});
      return json(res,200,{total:orders.length,paid:paid.length,pending:orders.filter(o=>o.payment==='Pending').length,failed:orders.filter(o=>o.payment==='Failed').length,refunded:orders.filter(o=>o.payment==='Refunded').length,reportsReady:orders.filter(o=>o.report==='Ready').length,reportsPending:orders.filter(o=>o.report!=='Ready').length,todayOrders:todayPaid.length,revenue:money,byPackage,byCountry});
    }
    if(req.method==='PATCH'&&req.url.startsWith('/api/admin/orders/')){
      if(!requireAdmin(req,res))return;
      const id=decodeURIComponent(req.url.slice('/api/admin/orders/'.length)); const x=await body(req); const allowed={payment:['Pending','Paid','Failed','Refunded'],report:['Pending','Processing','Ready','Failed']}; const patch={};
      if(allowed.payment.includes(x.payment))patch.payment=x.payment; if(allowed.report.includes(x.report))patch.report=x.report; if(x.customer!==undefined)patch.customer=String(x.customer).slice(0,120); if(x.email!==undefined)patch.email=String(x.email).slice(0,200).toLowerCase();
      const updated=await db.updateOrder(id,patch); if(!updated)return json(res,404,{error:'Order not found.'}); return json(res,200,{order:adminOrderView(updated)});
    }
    if(req.method==='POST'&&req.url.startsWith('/api/admin/orders/')&&req.url.endsWith('/regenerate')){
      if(!requireAdmin(req,res))return;
      const id=decodeURIComponent(req.url.slice('/api/admin/orders/'.length,-'/regenerate'.length)); const order=await db.getOrder(id); if(!order)return json(res,404,{error:'Order not found.'}); if(order.payment!=='Paid')return json(res,409,{error:'Only paid orders can generate a report.'});
      await db.updateOrder(id,{report:'Processing'}); const host=req.headers.host; const forwarded=req.headers['x-forwarded-proto']; const base=host?`${forwarded||'http'}://${host}`:''; const result=await generateReport(await db.getOrder(id),base); if(!result.ok)return json(res,502,{error:result.error||'Report generation failed.'}); return json(res,200,{ok:true,order:adminOrderView(await db.getOrder(id)),reportUrl:result.reportUrl});
    }
    if(req.method==='POST'&&req.url.startsWith('/api/admin/orders/')&&req.url.endsWith('/resend')){
      if(!requireAdmin(req,res))return;
      const id=decodeURIComponent(req.url.slice('/api/admin/orders/'.length,-'/resend'.length)); const order=await db.getOrder(id); if(!order)return json(res,404,{error:'Order not found.'}); if(order.payment!=='Paid'||!order.reportToken)return json(res,409,{error:'A paid ready report is required before resending.'});
      const host=req.headers.host; const forwarded=req.headers['x-forwarded-proto']; const base=PUBLIC_BASE_URL|| (host?`${forwarded||'http'}://${host}`:''); const result=await sendReportEmail(order,`${base}/report.html?token=${encodeURIComponent(order.reportToken)}`); return json(res,200,{ok:true,email:result});
    }
    if(req.method==='POST'&&req.url.startsWith('/api/admin/orders/')&&req.url.endsWith('/refund')){
      if(!requireAdmin(req,res))return;
      const id=decodeURIComponent(req.url.slice('/api/admin/orders/'.length,-'/refund'.length)); const order=await db.getOrder(id); if(!order)return json(res,404,{error:'Order not found.'}); if(order.payment!=='Paid')return json(res,409,{error:'Only paid orders can be refunded.'});
      const x=await body(req); const amount=x.amount===undefined||x.amount===''?Number(order.amount):Number(x.amount); if(!(amount>0)||amount>Number(order.amount))return json(res,400,{error:'Refund amount is invalid.'});
      const refund=await paypalRefund(order.paypalCaptureId,amount,order.currency); const full=Math.abs(amount-Number(order.amount))<0.001; const updated=await db.updateOrder(id,{payment:full?'Refunded':'Paid'}); return json(res,200,{ok:true,refund,order:adminOrderView(updated)});
    }

    if(req.method==='GET'&&req.url.startsWith('/api/reports/')){
      const token=decodeURIComponent(req.url.slice('/api/reports/'.length));if(!token)return json(res,400,{error:'Report token required.'});const order=await db.findByReportToken(token);if(!order||order.payment!=='Paid'||!order.reportData)return json(res,404,{error:'Report not available.'});return json(res,200,{report:{id:order.id,vin:order.vin,country:order.country,pkg:order.pkg,date:order.date,data:order.reportData}});
    }
    if(req.method==='POST'&&req.url==='/api/webhook'){
      const secret=req.headers['x-webhook-secret']||'';if(!WEBHOOK_SECRET||!safeEqual(secret,WEBHOOK_SECRET))return json(res,401,{error:'Invalid webhook secret'});const x=await body(req);if(!x.id)return json(res,400,{error:'id is required'});const existing=await db.getOrder(x.id);if(existing)await db.updateOrder(x.id,x);else await db.insertOrder({...x,createdAt:x.createdAt||new Date().toISOString()});return json(res,200,{ok:true});
    }
    return serveFile(req,res);
  }catch(e){console.error(e);return json(res,500,{error:e.message||'Server error'})}
});

db.initDb().then(()=>server.listen(PORT,()=>console.log(`VINDECORD running on http://localhost:${PORT}`))).catch(e=>{console.error('Database init failed:',e);server.listen(PORT,()=>console.log(`VINDECORD running on http://localhost:${PORT}`))});
