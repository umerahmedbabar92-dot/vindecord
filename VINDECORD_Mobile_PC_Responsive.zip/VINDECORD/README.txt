VINDECORD Global Website Package

Target markets:
- New Zealand (NZD)
- Australia (AUD)
- South Africa (ZAR)

The customer site includes a market/currency selector and configurable local pricing. The admin dashboard is included separately.

IMPORTANT BEFORE PRODUCTION:
- Connect a real payment provider that supports your business/entity and target customers.
- Connect an authorized vehicle-history data provider with coverage for each target market.
- Use a backend/database for orders and payment webhooks.
- Keep all payment and API secrets on the server, never in frontend HTML/JS.
- Add your final privacy policy, terms, refund policy and business/contact details.

Website upgrades included in this build:
- Professional sample report page
- Public order tracking page and secure email+order lookup endpoint
- Contact/support section
- Privacy Policy, Terms & Conditions, Refund Policy pages
- Improved navigation and customer journey
- Existing VIN decoder, packages, payment-ready checkout and embedded admin dashboard retained
