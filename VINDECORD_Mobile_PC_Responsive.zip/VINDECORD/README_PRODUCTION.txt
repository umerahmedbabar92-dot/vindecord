VINDECORD PRODUCTION HANDOFF

Already implemented in this package:
- Clean hero image without the old screenshot/ghost content.
- Public navbar no longer exposes Admin Login.
- Market selector: NZ/AU/ZA and server-side currency/price validation.
- PayPal + eligible PayPal Card Fields flow.
- Server-side PayPal amount/currency verification.
- Admin session cookie and protected /api/orders endpoint.
- PostgreSQL support via DATABASE_URL, with local JSON fallback for development.
- Secure random report tokens.
- Provider adapter at POST VEHICLE_API_URL with Authorization/x-api-key support.
- Report page at /report.html?token=...
- Optional Resend email delivery.
- Health endpoint at /api/health.

External setup still required before accepting real customers:
1. Create/configure a PayPal Business app and put live credentials in Vercel Environment Variables.
2. Select and contract a vehicle-history provider that permits commercial report resale; put its documented API URL/key in Vercel Environment Variables.
3. Create a production PostgreSQL database and set DATABASE_URL.
4. Configure RESEND_API_KEY and REPORT_FROM_EMAIL if email delivery is desired.
5. Set ADMIN_EMAIL, ADMIN_PASSWORD and SESSION_SECRET to strong production values.
6. Set PUBLIC_BASE_URL=https://vindecord.com after the domain is connected.
7. Deploy the package to Vercel and test in PayPal Sandbox first.
8. Switch PAYPAL_MODE=live only after sandbox payment, order creation, report generation and email delivery are all verified.
9. Add vindecord.com in Vercel Project > Settings > Domains and follow the DNS records Vercel provides at your domain registrar.

Important: the code cannot invent or bypass third-party credentials, provider contracts, or DNS access. Those values must be supplied by the account owners.
